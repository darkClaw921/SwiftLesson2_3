/*:
 ## Упражнение - приведение типов и их контроль
 
 Создайте коллекцию типа [Any], включающую несколько вещественных чисел, целых, строк и булевых значений.  Распечатайте содержимое коллекции.
 */
let items: [Any] = [1.23, 2.3, 2, 4, "hello", "23", true, false]

for item in items {
    print(item)
}


/*:
 Пройдите по всем элементам коллекции.  Для каждого целого, напечайте "Целое число " и его значение.  Повторите то же самое для вещественных чисел, строк и булевых значений.
 */
for item in items {
    if let _ = item as? Int {
        print("Целое число - \(item)")
    } else if let _ = item as? Double {
        print("Вещественное число - \(item)")
    } else if let _ = item as? String {
        print("Строка - \(item)")
    } else if let _ = item as? Bool {
        print("Булево значение - \(item)")
    }
}

/*:
 Создайте словарь [String : Any], где все значения — это смесь вещественных и целых чисел, строк и булевых значений.  Выведите пары ключ/значения для всех элементов коллекции.
 */
let itemsAny: [String: Any] = ["12.3": 2, "hello": true,    "job": "main",
                              "65.67": 54,  "bye": false, "leans": "100"]

for item in itemsAny {
    print("Ключь: \(item.key) значение: \(item.value)")
}

/*:
 Создайте переменную `total` типа `Double`, равную 0.  Переберите все значения словаря, и добавьте значение каждого целого и вещественного числа к значению вашей переменной.  Для каждой строки добавьте 1.  Для каждого булева значения, добавьте 2, в случае, если значение равно `true`, либо вычтите 3, если оно `false`.  Напечатайте значение `total`.
 */
var total = 0.0

for item in itemsAny {
    
    if let _ = item.value as? String {
        total += 1
    } else if let itemType = item.value as? Bool {
        total += itemType ? 2 : -3
    } else if let itemType = item.value as? Int {
        total += Double(itemType)
    } else if let itemType = item.value as? Double {
        total += itemType
    }
}

print(total)

/*:
 Обнулите переменную total и снова пройдите по всей коллекции, прибавляя к ней все целые и вещественные числа.  Для каждой строки, встретившейся на пути, попробуйте сконвертировать её в число, и добавьте это значение к общему.  Игнорируйте булевы значения.  Распечатайте итог.
 */
total = 0

for item in itemsAny {
    
    if let itemType = item.value as? String {
        if Double(itemType) != nil {
            total += Double(itemType)!
        }
    } else if let itemType = item.value as? Int {
        total += Double(itemType)
    } else if let itemType = item.value as? Double {
        total += itemType
    }
}

print (total)
//: страница 1 из 2  |  [Далее: упражнение для приложения - типы тренировок](@next)
